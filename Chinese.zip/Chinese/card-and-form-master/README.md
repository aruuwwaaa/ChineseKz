# card-and-form
A simple card showing user details and social media vote counts.
This was built using html, css, javascript and animate css library. Feel free to use it in your projects 👋

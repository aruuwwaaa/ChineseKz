# Certificate-Generator
Generate PDF Certificate menggunakan Javascript dan library PDF-lib.js dan FileSaver.js

# Contoh PDF
![Sample pdf](https://i.imgur.com/VIIjR2d.png)
